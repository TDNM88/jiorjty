"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type Language = "en" | "vi"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const translations = {
  en: {
    // Header
    title: "BinaryTrade",
    trade: "Trade",
    markets: "Markets",
    portfolio: "Portfolio",
    connect_wallet: "Connect Wallet",
    connected: "Connected",
    logout: "Logout",

    // Trading
    place_trade: "Place Trade",
    buy_up: "Buy (Up)",
    sell_down: "Sell (Down)",
    trading_pair: "Trading Pair",
    amount: "Amount",
    duration: "Duration",
    potential_payout: "Potential Payout",
    place_buy_order: "Place Buy Order",
    place_sell_order: "Place Sell Order",
    up_to_payout: "Up to 85% Payout",

    // Wallet
    wallet: "Wallet",
    total_balance: "Total Balance",
    todays_pnl: "Today's P&L",
    win_rate: "Win Rate",
    deposit: "Deposit",
    withdraw: "Withdraw",
    connect_now: "Connect Now",
    connect_wallet_to_start: "Connect your wallet to start trading",

    // Trade History
    trade_history: "Trade History",
    all: "All",
    pending: "Pending",
    completed: "Completed",
    cancelled: "Cancelled",
    pair: "Pair",
    type: "Type",
    status: "Status",
    time: "Time",
    no_trades_found: "No trades found",

    // Markets
    search_markets: "Search markets...",
    price: "Price",
    change_24h: "24h Change",
    volume: "Volume",
    market_cap: "Market Cap",
    action: "Action",

    // Portfolio
    portfolio_overview: "Portfolio Overview",
    performance: "Performance",
    recent_activity: "Recent Activity",
    total_trades: "Total Trades",
    best_trade: "Best Trade",
    worst_trade: "Worst Trade",
    total_assets: "Total Assets",

    // Login
    login: "Login",
    username: "Username",
    password: "Password",
    connecting: "Connecting...",
    demo_account: "Demo Account",
    enter_username: "Enter username",
    enter_password: "Enter password",
    invalid_credentials: "Invalid credentials. Try demo/demo123",
    login_failed: "Login failed. Please try again.",

    // Messages
    connect_wallet_first: "Please connect your wallet first!",
    invalid_amount: "Please enter a valid amount",
    insufficient_balance: "Insufficient balance",
    deposit_coming_soon: "Deposit functionality coming soon!",
    withdraw_coming_soon: "Withdraw functionality coming soon!",
    trade_placed_successfully: "Trade placed successfully!",

    // Market Stats
    market_stats: "Market Stats",
    volume_24h: "24h Volume",
    active_traders: "Active Traders",
    success_rate: "Success Rate",

    // Durations
    "30s": "30 Seconds",
    "1m": "1 Minute",
    "5m": "5 Minutes",
    "15m": "15 Minutes",
    "30m": "30 Minutes",
    "1h": "1 Hour",

    // Welcome
    welcome_title: "Welcome to the Future of Trading",
    welcome_subtitle: "Experience seamless binary options trading with real-time data and intuitive controls",
    get_started: "Get Started",
    fast_execution: "Fast Execution",
    secure_platform: "Secure Platform",
    realtime_data: "Real-time Data",
  },
  vi: {
    // Header
    title: "BinaryTrade",
    trade: "Giao Dịch",
    markets: "Thị Trường",
    portfolio: "Danh Mục",
    connect_wallet: "Kết Nối Ví",
    connected: "Đã Kết Nối",
    logout: "Đăng Xuất",

    // Trading
    place_trade: "Đặt Lệnh",
    buy_up: "Mua (Tăng)",
    sell_down: "Bán (Giảm)",
    trading_pair: "Cặp Giao Dịch",
    amount: "Số Lượng",
    duration: "Thời Gian",
    potential_payout: "Lợi Nhuận Tiềm Năng",
    place_buy_order: "Đặt Lệnh Mua",
    place_sell_order: "Đặt Lệnh Bán",
    up_to_payout: "Lợi nhuận lên đến 85%",

    // Wallet
    wallet: "Ví",
    total_balance: "Tổng Số Dư",
    todays_pnl: "P&L Hôm Nay",
    win_rate: "Tỷ Lệ Thắng",
    deposit: "Nạp Tiền",
    withdraw: "Rút Tiền",
    connect_now: "Kết Nối Ngay",
    connect_wallet_to_start: "Kết nối ví để bắt đầu giao dịch",

    // Trade History
    trade_history: "Lịch Sử Giao Dịch",
    all: "Tất Cả",
    pending: "Đang Chờ",
    completed: "Hoàn Thành",
    cancelled: "Đã Hủy",
    pair: "Cặp",
    type: "Loại",
    status: "Trạng Thái",
    time: "Thời Gian",
    no_trades_found: "Không tìm thấy giao dịch",

    // Markets
    search_markets: "Tìm kiếm thị trường...",
    price: "Giá",
    change_24h: "Thay Đổi 24h",
    volume: "Khối Lượng",
    market_cap: "Vốn Hóa",
    action: "Hành Động",

    // Portfolio
    portfolio_overview: "Tổng Quan Danh Mục",
    performance: "Hiệu Suất",
    recent_activity: "Hoạt Động Gần Đây",
    total_trades: "Tổng Giao Dịch",
    best_trade: "Giao Dịch Tốt Nhất",
    worst_trade: "Giao Dịch Tệ Nhất",
    total_assets: "Tổng Tài Sản",

    // Login
    login: "Đăng Nhập",
    username: "Tên Đăng Nhập",
    password: "Mật Khẩu",
    connecting: "Đang Kết Nối...",
    demo_account: "Tài Khoản Demo",
    enter_username: "Nhập tên đăng nhập",
    enter_password: "Nhập mật khẩu",
    invalid_credentials: "Thông tin không hợp lệ. Thử demo/demo123",
    login_failed: "Đăng nhập thất bại. Vui lòng thử lại.",

    // Messages
    connect_wallet_first: "Vui lòng kết nối ví trước!",
    invalid_amount: "Vui lòng nhập số lượng hợp lệ",
    insufficient_balance: "Số dư không đủ",
    deposit_coming_soon: "Tính năng nạp tiền sẽ sớm ra mắt!",
    withdraw_coming_soon: "Tính năng rút tiền sẽ sớm ra mắt!",
    trade_placed_successfully: "Đặt lệnh thành công!",

    // Market Stats
    market_stats: "Thống Kê Thị Trường",
    volume_24h: "Khối Lượng 24h",
    active_traders: "Trader Hoạt Động",
    success_rate: "Tỷ Lệ Thành Công",

    // Durations
    "30s": "30 Giây",
    "1m": "1 Phút",
    "5m": "5 Phút",
    "15m": "15 Phút",
    "30m": "30 Phút",
    "1h": "1 Giờ",

    // Welcome
    welcome_title: "Chào Mừng Đến Với Tương Lai Giao Dịch",
    welcome_subtitle:
      "Trải nghiệm giao dịch tùy chọn nhị phân liền mạch với dữ liệu thời gian thực và điều khiển trực quan",
    get_started: "Bắt Đầu",
    fast_execution: "Thực Thi Nhanh",
    secure_platform: "Nền Tảng Bảo Mật",
    realtime_data: "Dữ Liệu Thời Gian Thực",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")

  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language
    if (savedLanguage && (savedLanguage === "en" || savedLanguage === "vi")) {
      setLanguage(savedLanguage)
    }
  }, [])

  const changeLanguage = (lang: Language) => {
    setLanguage(lang)
    localStorage.setItem("language", lang)
  }

  const t = (key: string): string => {
    return translations[language][key as keyof (typeof translations)[typeof language]] || key
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage: changeLanguage, t }}>{children}</LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
